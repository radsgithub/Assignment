// import necessary packages
const express = require('express') 
const app = express()
const reader = require('xlsx')
const bodyparser = require('body-parser')
const fs = require('fs');
const readXlsxFile = require('read-excel-file/node');
const mysql = require('mysql')

//bodyParser.json returns middleware that only parses JSON.
app.use(bodyparser.json())

//bodyParser.urlencoded({ extended: true }) - middleware for parsing bodies from URL.
app.use(bodyparser.urlencoded({
    extended: true
}))

// Database connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Welcome@123^",
    database: "node"
})

db.connect(function (err) {
    if (err) {
        return console.error('error: ' + err.message);
    }
    console.log('Connected to the MySQL server.');
})

//Important Routes:

//To read pets excel file and insert their data into database
app.post('/', (req, res) => {

    //readXlsxFile function that reads the excel file.

    readXlsxFile('pet.xlsx').then((rows) => {
        rows.shift(); //to remove headers row

        let query = 'INSERT INTO pets (name,type,breed, age) VALUES ?';

        db.query(query, [rows], (error, response) => {
            console.log(error || response);
        })
    })
    res.send("data has been inserted in pets table!")
})

//To insert specific data of pets in database table.

app.post("/api/pet", (req, res) => {
    var name = req.body.name
    var type = req.body.type
    var breed = req.body.breed
    var age = req.body.age

    var data = db.query('INSERT INTO pets (name,type,breed,age) VALUES (?,?,?,?)', [name, type, breed, age])
    console.log(data)
    res.send("data inserted!")
})

//To get the whole data from table and corresponsing to given id's data from table.

app.get("/api/pet", async (req, res) => {
    var id = req.query.id
    if (id) {
        db.query('SELECT * FROM pets where id= ?', id, (err, rows) => {
            console.log(rows)
            res.send({ data: rows })
        });
    }
    else {
        db.query('SELECT * FROM pets', (err, rows) => {
            console.log(rows)
            res.send({ data: rows })
        });
    }

})

//To update tha details of pets according to given id.

app.patch("/api/pet", async (req, res) => {
    var id = req.query.id
    var name = req.body.name
    var type = req.body.type
    var breed = req.body.breed
    var age = req.body.age

    db.query('UPDATE `pets` SET `name`=?,`type`=?,`breed`=?,`age`=? WHERE id=?', [name, type, breed, age, id], (err, rows) => {
        console.log(rows)
        res.send({ data: rows })
    });
})

//To delete the data of given id
app.delete("/api/pet", async (req, res) => {
    var id = req.query.id

    db.query('DELETE FROM pets WHERE id=?', [id], (err, rows) => {
        console.log(rows)
        res.send("id: " + id + " details has been deleted.")
    });
})


//start the server.
let server = app.listen(8080, function () {
    let host = server.address().address
    let port = server.address().port
    console.log("App listening at http://%s:%s", host, port)
})